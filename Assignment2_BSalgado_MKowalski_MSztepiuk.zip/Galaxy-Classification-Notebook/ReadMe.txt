Assignment No.2

Supervised Learning

| Bernardo Gil Alves Salgado (up202004493) | Michal Sztepiuk (up202302748) | Michal Dawid Kowalski (up202401554) |

AI's Introduction’s second practical assignment consists of the application of machine learning models and algorithms related to supervised learning.

Supervised learning involves analyzing and preparing the dataset, identifying the target variable, splitting the data into training and test sets, selecting and tuning a learning algorithm, and evaluating the model's performance on the test set.


Dataset: SDSS Galaxy Classification DR18 (https://www.kaggle.com/datasets/bryancimo/sdss-galaxy-classification-dr18)

Brief: 100,000 rows of photometric image data from the Sloan Digital Sky Survey.

Description: The Sloan Digital Sky Survey (SDSS) has searched about one-third of the sky and found around 1 billion objects and almost 3 million of those are galaxies. It contains 100,000 rows of photometric image data and the galaxy subclass is limited to two types, 'STARFORMING' or 'STARBURST

For overview and results comparison, see the attached Presentation.pdf.


---------------------------------------------------------------------------------------------------
HOW TO RUN?

1. Open ClassificationTaskNotebook.ipynb in Jupyter Lab / Notebook.

---------------------------------------------------------------------------------------------------

The notebook uses the following libraries:
pandas
numpy
matplotlib
seaborn
sklearn
imblearn
scipy
tensorflow
numpy